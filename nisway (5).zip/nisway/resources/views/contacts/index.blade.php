@include('layouts.inc.header')

@include('layouts.inc.sidebar')

<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> Contacts </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Contact</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Contact Lists</li>
                </ol>
            </nav>
        </div>

        <div class="row">
            <div class="col-lg-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Contact List</h4>

                        <!-- Display Success or Error Messages -->
                        @if(session('success'))
                            <div class="alert alert-success">{{ session('success') }}</div>
                        @elseif(session('error'))
                            <div class="alert alert-danger">{{ session('error') }}</div>
                        @endif

                        <!-- Import XML Form, Align Button to Right -->
                        <div class="text-right mb-3">
                            <form action="{{ url('contacts/import') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                               
                                    <label for="xml_file">Upload XML File</label>
                                    <input type="file" name="xml_file" accept=".xml" class="form-control" required>
                                
                                <button type="submit" class="btn btn-primary">Import XML</button>
                            </form>
                        </div>

                        <!-- Contacts Table -->
                        <div class="table-responsive mt-3">
                            <table class="table table-bordered" id="contactsTable">
                                <thead>
                                    <tr>
                                        <th> # </th>
                                        <th> Name </th>
                                        <th> Mobile no </th>
                                        <th> Action </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($contacts as $key => $contact)
                                    <tr>
                                        <td>{{ $key + 1 }}</td>
                                        <td>{{ $contact->name }}</td>
                                        <td>{{ $contact->mobile_no }}</td>
                                        <td>
                                            <a href="{{ url('contacts/edit', $contact->id) }}" class="btn btn-warning btn-sm">Edit</a>
                                            <form action="{{ url('contacts/destroy', $contact->id) }}" method="POST" style="display:inline;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
@include('layouts.inc.footer')
<script>
    $(document).ready(function() {
        $('#contactsTable').DataTable({
            "paging": true,
            "ordering": true,
            "info": true
        });
    });
    </script>