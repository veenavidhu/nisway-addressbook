@include('layouts.inc.header')

@include('layouts.inc.sidebar')

<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> Edit Contact </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Contact</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Contact</li>
                </ol>
            </nav>
        </div>

        <div class="row">
            <div class="col-lg-6 grid-margin mx-auto">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Edit Contact</h4>

                        @if(session('success'))
                            <div class="alert alert-success">{{ session('success') }}</div>
                        @elseif(session('error'))
                            <div class="alert alert-danger">{{ session('error') }}</div>
                        @endif

                        <form action="{{ url('contacts/update', $contact->id) }}" method="POST">
                            @csrf
                            @method('PUT')

                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" name="name" class="form-control" value="{{ $contact->name }}" required>
                            </div>

                            <div class="form-group">
                                <label for="mobile_no">Mobile No</label>
                                <input type="text" name="mobile_no" class="form-control" value="{{ $contact->mobile_no }}" required>
                            </div>

                            <button type="submit" class="btn btn-success">Update Contact</button>
                            <a href="{{ url('contacts') }}" class="btn btn-secondary">Cancel</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('layouts.inc.footer')
