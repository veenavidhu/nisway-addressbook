<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Task;

class TaskTable extends Component
{
    public $tasks;
    public $editing = [];
    
    protected $rules = [
        'tasks.*.name' => 'required|string',
        'tasks.*.status' => 'required|string',
        'tasks.*.pipeline_step' => 'required|string',
    ];

    public function mount()
    {
        $this->tasks = Task::all();
    }

    public function edit($index)
    {
        $this->editing[$index] = true;
    }

    public function save($index)
    {
        $this->validate();
        $this->tasks[$index]->save();
        $this->editing[$index] = false;
        session()->flash('message', 'Task updated successfully!');
    }

    public function render()
    {
        return view('livewire.task-table');
    }
}

