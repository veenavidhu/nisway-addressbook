<?php

namespace App\Http\Controllers;

use App\Models\Contacts;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {

        $contactCount = Contacts::count(); // Get total contacts count

    return view('dashboard.index', compact('contactCount'));
    }

}
