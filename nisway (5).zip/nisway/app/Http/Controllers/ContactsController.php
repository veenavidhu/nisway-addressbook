<?php

namespace App\Http\Controllers;

use App\Models\Contacts;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ContactsController extends Controller
{
    public function index()
    {
        $contacts = Contacts::all();
        return view('contacts.index', compact('contacts'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'mobile_no' => 'required|string|max:20',
        ]);

        Contacts::create($request->all());
        return redirect()->back()->with('success', 'Contact added successfully');
    }

    public function destroy($id)
    {
        Contacts::findOrFail($id)->delete();
        return redirect()->back()->with('success', 'Contact deleted successfully');
    }
    public function import(Request $request)
    {
        $request->validate([
            'xml_file' => 'required|file|mimes:xml|max:10240',
        ]);
    
        if ($request->hasFile('xml_file')) {
            try {
                // Load the XML file
                $xml = simplexml_load_file($request->file('xml_file')->getRealPath());
    
                if ($xml === false) {
                    return redirect()->back()->with('error', 'Failed to parse the XML file.');
                }
    
                DB::beginTransaction();
    
                // Loop through each contact in the XML file
                foreach ($xml->contact as $contact) {
                    // Log the contact data for debugging
                    Log::info('Importing contact', [
                        'name' => (string) $contact->name,
                        'phone' => (string) $contact->phone
                    ]);
    
                    // Create the contact in the database
                    Contacts::create([
                        'name' => (string) $contact->name,
                        'mobile_no' => preg_replace('/\s+/', '', (string) $contact->phone), // Remove spaces from phone number
                    ]);
                }
    
                DB::commit();
                return redirect()->back()->with('success', 'Contacts imported successfully');
            } catch (\Exception $e) {
                DB::rollBack();
                Log::error('Error importing contacts', ['error' => $e->getMessage()]);
                return redirect()->back()->with('error', 'An error occurred while importing contacts.');
            }
        }
    
        return redirect()->back()->with('error', 'No XML file uploaded.');
    }
    


 public function edit($id)
{
    $contact = Contacts::findOrFail($id);
    return view('contacts.edit', compact('contact'));
}

public function update(Request $request, $id)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'mobile_no' => 'required|string|max:20',
    ]);

    $contact = Contacts::findOrFail($id);
    $contact->update([
        'name' => $request->name,
        'mobile_no' => $request->mobile_no,
    ]);

    return redirect(url('/contacts'))->with('success', 'Contact updated successfully.');
}

}
