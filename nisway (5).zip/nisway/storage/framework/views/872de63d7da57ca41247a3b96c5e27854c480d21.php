<?php echo $__env->make('layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Task <button type="button" class="btn btn-success btn-md pull-right" data-bs-toggle="modal" data-bs-target="#taskModal">Add Task
                        </button>&nbsp;&nbsp;<button type="button" class="btn btn-success btn-md pull-right" ><i class="fa fa-upload" aria-hidden="true"></i>
                    </button>&nbsp;&nbsp;&nbsp;&nbsp;</h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-dark">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="select-all"></th>
                                    <th>Task Name</th>
                                    <th>Link</th>
                                    <th>Status</th>
                                    <th>Pipeline Step</th>
                                    <th>Assigned To</th>
                                    <th>Reviewer</th>
                                    <th>Start Date</th>
                                    <th>Due Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $taskList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Section Header -->
                                    <tr>
                                        <td colspan="10">
                                            <a href="#" class="toggle-row text-light"
                                                data-target="<?php echo e(strtolower($category)); ?>">
                                                <i class="fas fa-chevron-down"></i> <?php echo e($category); ?>

                                                (<?php echo e(count($taskList)); ?>)
                                            </a>
                                        </td>
                                    </tr>

                                    <!-- Task Rows -->
                                    <?php $__currentLoopData = $taskList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="task-row <?php echo e(strtolower($category)); ?> d-none">
                                            <td><input type="checkbox"></td>
                                            <td><a href="#" class="editable editable-text" data-name="name" data-type="text"
                                                data-pk="<?php echo e($task['id']); ?>"><?php echo e($task['name']); ?></a></td>
                                            <td><a href="#" class="editable editable-text" data-name="name" data-type="text"
                                                    data-pk="<?php echo e($task['id']); ?>"><?php echo e($task['link']); ?></a></td>
                                            <td><a href="#" class="editable editable-status" data-name="status"
                                                    data-type="select"
                                                    data-pk="<?php echo e($task['id']); ?>"><?php echo e($task['status']); ?></a></td>
                                            <td><a href="#" class="editable editable-pipeline"
                                                    data-name="pipeline_step" data-type="select"
                                                    data-pk="<?php echo e($task['id']); ?>"><?php echo e($task['pipeline_step']); ?></a></td>
                                            <td><a href="#" class="editable editable-assigned-to"
                                                    data-name="assigned_to" data-type="select"
                                                    data-pk="<?php echo e($task['id']); ?>"><?php echo e($task['assigned_to']); ?></a></td>
                                            <td><a href="#" class="editable editable-reviewer" data-name="reviewer" data-type="select"
                                                    data-pk="<?php echo e($task['id']); ?>"><?php echo e($task['reviewer']); ?></a></td>
                                           
                                            <td><a href="#" class="editable editable-date" data-name="start_date"
                                                    data-type="text"
                                                    data-pk="<?php echo e($task['id']); ?>"><?php echo e($task['start_date']); ?></a></td>
                                            <td><a href="#" class="editable editable-date" data-name="due_date" data-type="text"
                                                    data-pk="<?php echo e($task['id']); ?>"><?php echo e($task['due_date']); ?></a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="modal fade" id="taskModal" tabindex="-1" aria-labelledby="taskModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create a new Task</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="mb-2">
                        <label class="form-label">Task Name:</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Link:</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Pipeline Step:</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Assigned To:</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">Start Date:</label>
                            <input type="date" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Due Date:</label>
                            <input type="date" class="form-control">
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Status:</label>
                        <input type="text" class="form-control">
                    </div>
                    
                    <div class="mb-2">
                        <label class="form-label">Description:</label>
                        <textarea class="form-control"></textarea>
                    </div>
                   
                  
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary">Create Task</button>
            </div>
        </div>
    </div>
</div>



<?php echo $__env->make('layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('scripts'); ?>



<script>
    // Dropdown options for 'Status'
    var statusOptions = [{
            value: 'waiting',
            text: 'Waiting to Start'
        },
        {
            value: 'in_progress',
            text: 'In Progress'
        },
        {
            value: 'completed',
            text: 'Completed'
        }
    ];

    // Dropdown options for 'Pipeline Step'
    var pipelineOptions = [{
            value: 'animation',
            text: 'Animation'
        },
        {
            value: 'blocking',
            text: 'Blocking'
        },
        {
            value: 'review',
            text: 'Review'
        }
    ];

    // Dropdown options for 'Assigned To'
    var assignedToOptions = [{
            value: 'user1',
            text: 'User 1'
        },
        {
            value: 'user2',
            text: 'User 2'
        },
        {
            value: 'user3',
            text: 'User 3'
        }
    ];

  
        // Dropdown options for 'Assigned To'
        var reviewerToOptions = [{
            value: 'user1',
            text: 'User 1'
        },
        {
            value: 'user2',
            text: 'User 2'
        },
        {
            value: 'user3',
            text: 'User 3'
        }
    ];
    $(document).ready(function() {
        $(".task-row").removeClass("d-none");
        $.fn.editable.defaults.mode = 'inline';
        $.fn.editable.defaults.ajaxOptions = {
            type: 'POST'
        };
        $.fn.editable.defaults.params = function(params) {
            params._token = '<?php echo e(csrf_token()); ?>';
            return params;
        };
        $('.editable-text').editable({
        type: 'text',
        url: '<?php echo e(url('tasks/update')); ?>',
        onblur: 'submit',
        success: function(response, newValue) {
            if(!response.success) return response.msg;
        }
    });
     // Initialize 'Start Date' field with date picker
    


        // Initialize 'Status' field as a dropdown
        $('.editable-status').editable({
            type: 'select',
            source: statusOptions,
            url: '<?php echo e(url('tasks/update')); ?>',
            onblur: 'submit',
            success: function(response, newValue) {
                if (!response.success) return response.msg;
            }
        });

        // Initialize 'Pipeline Step' field as a dropdown
        $('.editable-pipeline').editable({
            type: 'select',
            source: pipelineOptions,
            url: '<?php echo e(url('tasks/update')); ?>',
            onblur: 'submit',
            success: function(response, newValue) {
                if (!response.success) return response.msg;
            }
        });

        // Initialize 'Assigned To' field as a dropdown 
        $('.editable-assigned-to').editable({
            type: 'select',
            source: assignedToOptions,
            url: '<?php echo e(url('tasks/update')); ?>',
            onblur: 'submit',
            success: function(response, newValue) {
                if (!response.success) return response.msg;
            }
        });

        $('.editable-reviewer').editable({
            type: 'select',
            source: reviewerToOptions,
            url: '<?php echo e(url('tasks/update')); ?>',
            onblur: 'submit',
            success: function(response, newValue) {
                if (!response.success) return response.msg;
            }
        });


        $(".toggle-row").click(function(e) {
            e.preventDefault();
            let target = $(this).data("target");
            $("tr." + target).toggleClass("d-none");
            $(this).find("i").toggleClass("fa-chevron-down fa-chevron-up");
        });


        // Select all checkboxes
        $("#select-all").click(function() {
            $("tbody input[type='checkbox']").prop('checked', this.checked);
        });

         // Attach Bootstrap Datepicker
         $('.editable-date').datepicker({
    format: 'dd-mm-yyyy',
    autoclose: true,
    todayHighlight: true,
    orientation: "bottom",  // Ensures it appears below the input
    container: 'body'       // Prevents overflow issues
}).on('changeDate', function(e) {
    $(this).editable('setValue', e.format('dd-mm-yyyy')).submit();
});

    });

</script>
<?php /**PATH D:\projects\htdocs\MATRIX_X\resources\views/task/index.blade.php ENDPATH**/ ?>