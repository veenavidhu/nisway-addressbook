
  <?php echo $__env->make('layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
      <?php echo $__env->make('layouts.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
            

              <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
                <div class="card shadow-lg rounded overflow-hidden">
                    <!-- Project Thumbnail -->
                    <div class="bg-image" style="background: url('<?php echo e(asset('assets/uploads/projects/bao-bao.jpg')); ?>') center/contain no-repeat; height: 120px;">
                    </div>
                    
                    <!-- Project Name -->
                    <div class="card-footer bg-dark text-center">
                        <a href="<?php echo e(url('project/tasklist')); ?>" class="text-decoration-none text-light font-weight-bold">BAO BAO</a>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
              <div class="card shadow-lg rounded overflow-hidden">
                  <!-- Project Thumbnail -->
                  <div class="bg-image" style="background: url('<?php echo e(asset('assets/uploads/projects/brush-brigade.jpg')); ?>') center/contain no-repeat; height: 120px;">
                  </div>
                  
                  <!-- Project Name -->
                  <div class="card-footer bg-dark text-center">
                      <a href="#" class="text-decoration-none text-light font-weight-bold">Brush Brigade</a>
                  </div>
              </div>
          </div>
          <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
            <div class="card shadow-lg rounded overflow-hidden">
                <!-- Project Thumbnail -->
                <div class="bg-image" style="background: url('<?php echo e(asset('assets/uploads/projects/tiny-head.png')); ?>') center/contain no-repeat; height: 120px;">
                </div>
                
                <!-- Project Name -->
                <div class="card-footer bg-dark text-center">
                    <a href="#" class="text-decoration-none text-light font-weight-bold">Tiny Head</a>
                </div>
            </div>
        </div>
            </div>
            
            
            
            
            
          </div>
          
        </div>



          <?php echo $__env->make('layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <style>
            .card1 {
    border-radius: 10px;
}
.bg-image {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #f5f5f5; /* Light background if image has transparency */
}
.card-footer1 {
    padding: 8px;
}
          </style><?php /**PATH D:\projects\htdocs\MATRIX_X\resources\views/dashboard/index.blade.php ENDPATH**/ ?>