<?php echo $__env->make('layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> Edit Contact </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Contact</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Contact</li>
                </ol>
            </nav>
        </div>

        <div class="row">
            <div class="col-lg-6 grid-margin mx-auto">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Edit Contact</h4>

                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php elseif(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <form action="<?php echo e(url('contacts/update', $contact->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" name="name" class="form-control" value="<?php echo e($contact->name); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="mobile_no">Mobile No</label>
                                <input type="text" name="mobile_no" class="form-control" value="<?php echo e($contact->mobile_no); ?>" required>
                            </div>

                            <button type="submit" class="btn btn-success">Update Contact</button>
                            <a href="<?php echo e(url('contacts')); ?>" class="btn btn-secondary">Cancel</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\projects\htdocs\nisway\resources\views/contacts/edit.blade.php ENDPATH**/ ?>