<?php echo $__env->make('layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- partial -->
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <a href="<?php echo e(url('contacts')); ?>" class="dashboard" >
                <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-9">
                                    <div class="d-flex align-items-center align-self-start">
                                        <h3 class="mb-0"><?php echo e($contactCount); ?></h3>

                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="icon icon-box-success ">
                                        <i class="fa fa-user" aria-hidden="true"></i>
                                    </div>
                                </div>

                               
                            </div>
                            <h6 class="text-muted font-weight-normal">Contacts</h6>
                        </div>
                    </div>
                </div>
            </a>

           
        </div>
    </div>
</div>

</div>

</div>



<?php echo $__env->make('layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .card1 {
        border-radius: 10px;
    }

    .bg-image {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #f5f5f5;
        /* Light background if image has transparency */
    }

    .card-footer1 {
        padding: 8px;
    }
</style>
<?php /**PATH D:\projects\htdocs\nisway\resources\views/dashboard/index.blade.php ENDPATH**/ ?>