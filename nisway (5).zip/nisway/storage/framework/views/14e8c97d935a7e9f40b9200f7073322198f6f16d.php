<?php echo $__env->make('layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> Contacts </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Contact</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Contact Lists</li>
                </ol>
            </nav>
        </div>

        <div class="row">
            <div class="col-lg-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Contact List</h4>

                        <!-- Display Success or Error Messages -->
                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php elseif(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <!-- Import XML Form, Align Button to Right -->
                        <div class="text-right mb-3">
                            <form action="<?php echo e(url('contacts/import')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                               
                                    <label for="xml_file">Upload XML File</label>
                                    <input type="file" name="xml_file" accept=".xml" class="form-control" required>
                                
                                <button type="submit" class="btn btn-primary">Import XML</button>
                            </form>
                        </div>

                        <!-- Contacts Table -->
                        <div class="table-responsive mt-3">
                            <table class="table table-bordered" id="contactsTable">
                                <thead>
                                    <tr>
                                        <th> # </th>
                                        <th> Name </th>
                                        <th> Mobile no </th>
                                        <th> Action </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($contact->name); ?></td>
                                        <td><?php echo e($contact->mobile_no); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('contacts/edit', $contact->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <form action="<?php echo e(url('contacts/destroy', $contact->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
<?php echo $__env->make('layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function() {
        $('#contactsTable').DataTable({
            "paging": true,
            "ordering": true,
            "info": true
        });
    });
    </script><?php /**PATH D:\projects\htdocs\nisway\resources\views/contacts/index.blade.php ENDPATH**/ ?>