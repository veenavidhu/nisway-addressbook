<div>
    <?php if(session()->has('message')): ?>
        <div style="color: green;"><?php echo e(session('message')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-dark">
        <tr>
            <th>Task Name</th>
            <th>Status</th>
            <th>Pipeline Step</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php if(isset($editing[$index]) && $editing[$index]): ?>
                    <input type="text" wire:model="tasks.<?php echo e($index); ?>.name">
                <?php else: ?>
                    <?php echo e($task->name); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if(isset($editing[$index]) && $editing[$index]): ?>
                    <input type="text" wire:model="tasks.<?php echo e($index); ?>.status">
                <?php else: ?>
                    <?php echo e($task->status); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if(isset($editing[$index]) && $editing[$index]): ?>
                    <input type="text" wire:model="tasks.<?php echo e($index); ?>.pipeline_step">
                <?php else: ?>
                    <?php echo e($task->pipeline_step); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if(isset($editing[$index]) && $editing[$index]): ?>
                    <button wire:click="save(<?php echo e($index); ?>)">Save</button>
                <?php else: ?>
                    <button wire:click="edit(<?php echo e($index); ?>)">Edit</button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH D:\projects\htdocs\MATRIX_X\resources\views/livewire/task-table.blade.php ENDPATH**/ ?>