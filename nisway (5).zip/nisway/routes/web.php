<?php

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Log;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
require __DIR__ . '/auth.php';

Route::get('/', function () {
    return view('auth.login');
});


// Clear application cache:
Route::get('/clear-cache', function () {
    Artisan::call('cache:clear');
    return 'Application cache has been cleared';
});

//Clear route cache:
Route::get('/route-cache', function () {
    Artisan::call('route:cache');
    return 'Routes cache has been cleared';
});

//Clear config cache:
Route::get('/config-cache', function () {
    Artisan::call('config:cache');
    return 'Config cache has been cleared';
});

// Clear view cache:
Route::get('/view-clear', function () {
    Artisan::call('view:clear');
    return 'View cache has been cleared';
});


Route::group(['middleware' => ['auth']], function () {
    Route::get('dashboard', 'App\Http\Controllers\DashboardController@index');
    Route::get('contacts', 'App\Http\Controllers\ContactsController@index');
    Route::post('contacts/import', 'App\Http\Controllers\ContactsController@import');
    Route::delete('contacts/destroy/{id}', 'App\Http\Controllers\ContactsController@destroy');
    Route::get('contacts/edit/{id}', 'App\Http\Controllers\ContactsController@edit');
    Route::put('contacts/update/{id}','App\Http\Controllers\ContactsController@update');

});