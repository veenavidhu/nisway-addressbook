<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Task;

class TaskSeeder extends Seeder
{
    public function run()
    {
        Task::insert([
            ['name' => 'Animation', 'status' => 'Waiting to Start', 'pipeline_step' => 'Animation'],
            ['name' => 'Blocking', 'status' => 'Task Created', 'pipeline_step' => 'Blocking'],
            ['name' => 'Caching', 'status' => 'Task Created', 'pipeline_step' => 'TD'],
            ['name' => 'Compositing', 'status' => 'Task Created', 'pipeline_step' => 'Compositing'],
            ['name' => 'FX', 'status' => 'Task Created', 'pipeline_step' => 'Effects'],
            ['name' => 'Lighting_BL', 'status' => 'Task Created', 'pipeline_step' => 'IFD'],
            ['name' => 'Lighting_CL', 'status' => 'Task Created', 'pipeline_step' => 'IFD'],
            ['name' => 'Staging', 'status' => 'Task Created', 'pipeline_step' => 'Staging'],
        ]);
    }
}
